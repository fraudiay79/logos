<?php
header("Status: 301");
header("Location: /video_unavailable/master.m3u8");
die();
